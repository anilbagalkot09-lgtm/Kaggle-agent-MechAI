class SearchTool:
    def search(self, query: str):
        # placeholder for a built-in search tool (mockable in tests)
        return {'query': query, 'results': []}
